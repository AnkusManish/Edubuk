-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 10, 2018 at 01:11 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Form`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback_details`
--

CREATE TABLE `feedback_details` (
  `id` int(255) NOT NULL,
  `Experience_review` varchar(255) NOT NULL,
  `Intelligence_review` varchar(255) NOT NULL,
  `Avail_services` varchar(255) NOT NULL,
  `Connect_edubuk` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback_details`
--

INSERT INTO `feedback_details` (`id`, `Experience_review`, `Intelligence_review`, `Avail_services`, `Connect_edubuk`, `created_at`) VALUES
(1, 'Average', 'No', 'Yes', 'May be', '2018-05-10 11:05:52'),
(2, 'Good', 'May be', 'May be', 'Yes', '2018-05-10 11:05:52'),
(3, 'Poor', 'No', 'No', 'Yes', '2018-05-10 11:06:09'),
(4, 'Good', 'Yes', 'No', 'May be', '2018-05-10 11:09:53');

-- --------------------------------------------------------

--
-- Table structure for table `form_details`
--

CREATE TABLE `form_details` (
  `id` int(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `Profile` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Hobbies` varchar(255) NOT NULL,
  `Recidence` varchar(255) NOT NULL,
  `Number` varchar(255) NOT NULL,
  `Edubuk_Groups` varchar(255) NOT NULL,
  `Answer` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_details`
--

INSERT INTO `form_details` (`id`, `Name`, `Gender`, `Profile`, `Email`, `Hobbies`, `Recidence`, `Number`, `Edubuk_Groups`, `Answer`, `created_at`) VALUES
(3, 'Manish', '', '', 'ankusmanish@gmail.com', '', 'hyd', '7799381828', '', 'hi there!', '2018-05-10 04:27:47'),
(4, 'Manish', '', '', 'ankusmanish@gmail.com', 'Reading,Dancing', 'hyd', '7799381828', '', 'saas', '2018-05-10 05:41:53'),
(5, 'anvesh', '', '', 'ankusmanish@gmail.com', 'Sports,on', 'hyd', '7799381828', '', 'Hi there! Its is woring', '2018-05-10 05:44:44'),
(6, 'Anish', '', '', 'ankusmanish@gmail.com', 'Reading,Dancing,Swimming', 'Vijaywada', '7799381828', 'PCP,PCT,SCE,ECA', 'It\'s working!\r\n', '2018-05-10 06:05:00'),
(7, 'Avinsah', 'Male', '', 'admin@infochord.com', 'Dancing,Singing,Swimming', 'hyd', '7799381828', 'PCP', '??', '2018-05-10 06:13:04'),
(8, 'Anish', 'Female', 'on', 'avinash@gmail.com', 'Dancing,Singing', 'hyd', '42424242', 'PCT', 'I hope it works.', '2018-05-10 06:19:17'),
(9, 'Manish', 'Female', 'Parent', 'admin@infochord.com', 'Singing,Bloging,on', 'hyd', '7799381828', 'SCE', 'dsddaaga sdf ', '2018-05-10 07:49:50'),
(10, 'Manish', 'Male', 'Service Provider', 'ankusmanish@gmail.com', 'Swimming,Sports', 'hyd', '7799381828', 'ECA', 'hi', '2018-05-10 11:02:42'),
(11, 'Manish', 'Male', 'Teacher', 'admin@infochord.com', 'Singing,Bloging', 'hyd', '7799381828', 'PCT,ECA', 'Success', '2018-05-10 11:10:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback_details`
--
ALTER TABLE `feedback_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_details`
--
ALTER TABLE `form_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback_details`
--
ALTER TABLE `feedback_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `form_details`
--
ALTER TABLE `form_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
