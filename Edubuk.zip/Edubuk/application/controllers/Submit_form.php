<?php
class Submit_form extends CI_Controller
{
    public function form_info()
    {
        // Initial form details
        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('recidence','Recidence','required');
        $this->form_validation->set_rules('number','Number','required');
        $this->form_validation->set_rules('email','Email','required|callback_check_email_exists');
        $this->form_validation->set_rules('answer','Answer','required');
        $this->form_validation->set_rules('boxes[]','Boxes','required');
        $this->form_validation->set_rules('group[]','Group','required');
        $this->form_validation->set_rules('optradio','Radio','required');
        $this->form_validation->set_rules('testradio','TestRadio','required');
        $this->form_validation->set_rules('profileradio','Profile_Radio','required');
        
        
        if($this->form_validation->run() == False)
        {
            $this->load->view('forms/initial_form');
        }
        else {
            $this->data_model->create_initial_form();
            redirect('Submit_form/success');
        }
    }
    
    public function index()
    {
       $this->load->view('forms/initial_form');
    }
    
    public function feedback_form()
    {
        $this->load->view('forms/feedback_form');
    }
    
    public function feedback_submit()
    {
        
        // feedback form details
        $this->form_validation->set_rules('experienceradio','Experience','required');
        $this->form_validation->set_rules('intelligenceradio','Intellegence','required');
        $this->form_validation->set_rules('serviceradio','Service','required');
        $this->form_validation->set_rules('connectradio','Connect_Edubuk','required');
        $this->form_validation->set_rules('careerradio','Career_guidance','required');
        
        if($this->form_validation->run() == False)
        {
            $this->load->view('forms/feedback_form');
        }
        else {
            $this->data_model->create_feedback_form();
            redirect('Submit_form/success');
        }
    }
    
    public function success()
    {
        $this->load->view('forms/success');
    }
    
    // check if username exists
    public function check_email_exists($email)
    {
        $this->form_validation->set_message('check_email_exists','Form has already been submitted with this Email address.');
        if($this->data_model->check_username_exists($email))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
 }
