<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<!-- script -->

<script type="text/javascript">
    $(function () {
        $("#chkother").click(function () {
            if ($(this).is(":checked")) {
                $("#otherText").removeAttr("disabled");
                $("#otherText").focus();
            } else {
                $("#otherText").attr("disabled", "disabled");
            }
        });
    });

</script>

<!---------------------------------------------------------------------->
<div class="container">
  <div class="">
  <div class="col-sm-offset-5 ">
  <h2>Initial Information Form</h2>
</div>
<?php echo validation_errors();?>
  <form class="form-horizontal well" action="<?php echo site_url('submit_form/form_info');?>" method="POST">
    <!-- Name -->
    <div class="form-group">
      <label class="control-label col-sm-2 col-sm-offset-2" for="">Name:</label>
      <div class="col-sm-5 ">
        <input type="text" class="form-control"  placeholder="Your Answer" name="name" required>
      </div>
    </div>
    <!---------------------------------------------------------------------->

    <!-- Gender -->
    <fieldset>
    <div class="form-group col-sm-offset-3">
      <label class="control-label col-sm-2 col-sm-offset-2" for="email">Gender:</label>
      <div class="radio">
        <label><input type="radio" name="optradio" value="Male"><strong>Male</strong></label>
      </div>
      <div class="radio col-sm-offset-4">
        <label><input type="radio" name="optradio" value="Female"><strong>Female</strong></label>
      </div>
   </div>
 </fieldset>
   <!---------------------------------------------------------------------->

   <!-- Profile -->
   <fieldset>
   <div class="form-group col-sm-offset-3">
     <label class="control-label col-sm-2 col-sm-offset-2" for="email">Select your profile:</label>
     <div class="radio">
       <label><input type="radio" name="profileradio" value="Parent"><strong>I am a Parent</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="profileradio" value="Teacher"><strong>I am a Teacher</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="profileradio" value="School Admin"><strong>I am a School Admin</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="profileradio" value="Student"><strong>I am a Student</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="profileradio" value="Service Provider"><strong>I am a Service Provider (Expert)</strong></label>
     </div>
  </div>
</fieldset>
    <!---------------------------------------------------------------------->

    <div class="form-group">
      <label class="control-label col-sm-2 col-sm-offset-2" for="email">Hobbies And Interests:</label>
        <div class="checkbox">
          <label><input type="checkbox" name="boxes[]" value="Reading"><strong>Reading</strong></label>
        </div>
        <div class="checkbox col-sm-offset-4">
          <label><input type="checkbox" name="boxes[]" value="Dancing"><strong>Dancing</strong></label>
        </div>
        <div class="checkbox col-sm-offset-4">
          <label><input type="checkbox" name="boxes[]" value="Singing"><strong>Singing</strong></label>
        </div>
        <div class="checkbox col-sm-offset-4">
          <label><input type="checkbox" name="boxes[]" value="Swimming"><strong>Swimming</strong></label>
        </div>
        <div class="checkbox col-sm-offset-4">
          <label><input type="checkbox" name="boxes[]" value="Sports"><strong>Sports</strong></label>
        </div>
        <div class="checkbox col-sm-offset-4">
          <label><input type="checkbox" name="boxes[]" value="Bloging"><strong>Bloging</strong></label>
        </div>
        <div class="checkbox col-sm-offset-4">
          <label ><input type="checkbox" name="boxes[]" id="chkother"><strong> Others </strong></label>
        </div>
        <div class="col-sm-offset-4">
        <textarea id="otherText" rows="4" cols="50" disabled="disabled"  name="extrainterests"></textarea>
        </div>
      </div>
     <!---------------------------------------------------------------------->

       <!-- Recidence -->
       <div class="form-group">
         <label class="control-label col-sm-2 col-sm-offset-2" for="">City of Recidence:</label>
         <div class="col-sm-5 ">
           <input type="text" class="form-control"  placeholder="Your Answer" name="recidence" required>
         </div>
       </div>
       <!---------------------------------------------------------------------->

       <!-- Contact Number -->
       <div class="form-group">
         <label class="control-label col-sm-2 col-sm-offset-2" for="">Contact Number:</label>
         <div class="col-sm-5 ">
           <input type="text" class="form-control" id="" placeholder="Your Answer" name="number" maxlength="10" required>
         </div>
       </div>
       <!---------------------------------------------------------------------->

       <!-- Email -->
       <div class="form-group">
         <label class="control-label col-sm-2 col-sm-offset-2" for="">Email Id:</label>
         <div class="col-sm-5 ">
           <input type="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" placeholder="Your Answer" name="email" required>
         </div>
       </div>
       <!---------------------------------------------------------------------->

       <!-- Group -->
       <div class="form-group">
         <label class="control-label col-sm-2 col-sm-offset-2" for="email">Which groups would you like to be a part of?</label>
         <div class="checkbox">
           <label><input type="checkbox" name="group[]" value="PCP"><strong>Parents-Connect-Parents (PCP), Private Group</strong></label>
         </div>
         <div class="checkbox col-sm-offset-4">
           <label><input type="checkbox" name="group[]" value="PCT"><strong>Parents-Connect-Teachers (PCT), Private Group</strong></label>
         </div>
         <div class="checkbox col-sm-offset-4">
           <label><input type="checkbox" name="group[]" value="SCE"><strong>Students-Connect-Experts (SCE), Private Group</strong></label>
         </div>
         <div class="checkbox col-sm-offset-4">
           <label><input type="checkbox" name="group[]" value="ECA"><strong>EduBuk-Connects-All (ECA), Public Group</strong></label>
         </div>
       </div>
        <!---------------------------------------------------------------------->
        
        <!-- Test Facility -->
         <fieldset>
           <div class="form-group col-sm-offset-3">
             <label class="control-label col-sm-6 col-sm-offset-2" for="email">Do you have the facility to give the test online?</label>
             <div class="radio col-sm-offset-4">
               <label><input type="radio" name="testradio" value="Yes(Parent)"><strong>Yes, I will use my parent’s Smart Phone with internet facility.</strong></label>
             </div>
             <div class="radio col-sm-offset-4">
               <label><input type="radio" name="testradio" value="Yes(Personal)"><strong>Yes, I have a laptop/ desktop/computer with internet facility.</strong></label>
             </div>
             <div class="radio col-sm-offset-4">
               <label><input type="radio" name="testradio" value="Yes(Institute)"><strong>I can use the facilities of internet provided by school/college/institute to appear for the test.</strong></label>
             </div>
             <div class="radio col-sm-offset-4">
               <label><input type="radio" name="testradio" value="No"><strong>No, I have no facility available as of now to give the test online.</strong></label>
             </div>
          </div>
        </fieldset>
     <!---------------------------------------------------------------------->

         <!-- Group -->
          <div class="form-group">
            <label class="control-label col-sm-12 " for="">Why do you want to join and be a part of EduBuk community (please let us know your reason to join the community so that we may serve you more aptly).</label>
            <div class="col-sm-offset-4">
              <textarea  rows="5" cols="70" name="answer" required></textarea>
            </div>
          </div>
          <!---------------------------------------------------------------------->

    <div class="form-group">
      <div class="col-sm-offset-6 col-sm-10">
        <button type="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>
  <a href="<?php echo site_url('submit_form/feedback_form');?>">Submit your feedback form here!</a>
</div>
</div>
</body>
</html>
