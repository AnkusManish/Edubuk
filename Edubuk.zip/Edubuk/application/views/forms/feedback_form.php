<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <div class="">
  <div class="col-sm-offset-5 ">
  <h2>Feedback form</h2>
</div>
<?php echo validation_errors();?>
  <form class="form-horizontal well" action="<?php echo site_url('submit_form/feedback_submit');?>" method="POST">
  
   <!-- Profile -->
    <div class="form-group">
       <label class="control-label col-sm-8" for="">How was your experience while appearing for multiple intelligence test?</label>
       <div class="row"></div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="experienceradio" value="Excellent"><strong>Excellent</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="experienceradio" value="Good"><strong>Good</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="experienceradio" value="Average"><strong>Average</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="experienceradio" value="Poor"><strong>Poor</strong></label>
     </div>
   </div>
<!---------------------------------------------------------------------->

   <!-- Profile -->
    <div class="form-group">
       <label class="control-label col-sm-8" for="">Do you think this test will be useful to test your intelligence type?</label>
       <div class="row"></div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="intelligenceradio" value="Yes"><strong>Yes, I think it will be useful for me.</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="intelligenceradio" value="May be"><strong>May Be, I am not sure.</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="intelligenceradio" value="No"><strong>No, I don't think it was useful for me.</strong></label>
     </div>
   </div>
<!---------------------------------------------------------------------->

   <!-- Profile -->
    <div class="form-group">
       <label class="control-label col-sm-8" for="">I am willing to avail other services offered by Edubuk for my all-round development</label>
       <div class="row"></div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="serviceradio" value="Yes"><strong>Yes for sure, I think it will be useful for me</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="serviceradio" value="May be"><strong>May Be, I am not sure.</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="serviceradio" value="No"><strong>No, I don't think it was useful for me.</strong></label>
     </div>
   </div>
<!---------------------------------------------------------------------->

   <!-- Profile -->
    <div class="form-group">
       <label class="control-label col-sm-8" for="">Do you want to be a part of Edubuk Community Connect Platform to connect with other students and experts? </label>
       <div class="row"></div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="connectradio" value="Yes"><strong>Yes for sure, I think it will be useful for me</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="connectradio" value="May be"><strong>May Be, I am not sure.</strong></label>
     </div>
     <div class="radio col-sm-offset-4">
       <label><input type="radio" name="connectradio" value="No"><strong>No, I don't think it was useful for me.</strong></label>
     </div>
   </div>
<!---------------------------------------------------------------------->

    <!-- Guidance -->
    <fieldset>
    <div class="form-group col-sm-offset-3">
      <label class="control-label col-sm-8" for="email">Would you like to opt for personalized Career Guidance Services?</label>
      <div class="row"></div>
      <div class="radio col-sm-offset-4">
        <label><input type="radio" name="careerradio" value="Yes"><strong>Yes</strong></label>
      </div>
      <div class="radio col-sm-offset-4">
        <label><input type="radio" name="careerradio" value="No"><strong>No</strong></label>
      </div>
   </div>
 </fieldset>
   <!---------------------------------------------------------------------->
	<div class="form-group">
      <div class="col-sm-offset-6 col-sm-10">
        <button type="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>
  	<a href="<?php echo site_url('submit_form/index');?>">Submit your feedback fom here!</a>
</div>
</div>
</body>
</html>
