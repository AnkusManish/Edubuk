<?php
class data_model extends CI_Model
{
    public function __construct(){
        $this->load->database();
    }
    
    public function create_initial_form()
    {
      
       
        $data = array(
            "Name"           =>           $this->input->post('name'),
            "Recidence"      =>           $this->input->post('recidence'),
            "Number"         =>           $this->input->post('number'),
            "Email"          =>           $this->input->post('email'),
            "Answer"         =>           $this->input->post('answer'),
            "Hobbies"        =>           implode(',',$this->input->post('boxes[]')),
            "Edubuk_Groups"  =>           implode(',',$this->input->post('group[]')),
            "Gender"         =>           $this->input->post('optradio'),
            "Test_facility"  =>           $this->input->post('testradio'),
            "Profile"        =>           $this->input->post('profileradio')
        );
        
        return $this->db->insert('form_details',$data);
    }
    
    public function create_feedback_form()
    {
        $data = array(
            "Experience_review"           =>        $this->input->post('experienceradio'),
            "Intelligence_review"         =>        $this->input->post('intelligenceradio'),
            "Avail_services"              =>        $this->input->post('serviceradio'),
            "Connect_edubuk"              =>        $this->input->post('connectradio'),
            "Career_guidance"             =>        $this->input->post('careerradio')
        );
        
        return $this->db->insert('feedback_details',$data);
    }
    
    //check username exists or not
    public function check_username_exists($email)
    {
        $query = $this->db->get_where('form_details', array('Email' => $email));
        if(empty($query->row_array()))
        {
            return TRUE;
        }
        else {
            return FALSE;
        }
        
    }
}